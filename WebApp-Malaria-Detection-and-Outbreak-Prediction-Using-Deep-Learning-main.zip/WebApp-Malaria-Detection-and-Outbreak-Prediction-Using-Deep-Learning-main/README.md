# WebApp-Malaria-Detection-and-Outbreak-Prediction-Using-Deep-Learning
Hosted Malaria Outbreak website link:  Manual Weather Inputs by user: https://malariaoutbreak-manualinputs.herokuapp.com/  
GitHub Repo: https://github.com/Areefahnk/WebApp-Manual-Inputs-MalariaOutbreak

Open Weather API live weather - based Outbreak prediction:  https://malariaoutbreak-ml.herokuapp.com/

Github Repo: https://github.com/Areefahnk/WebApp-Open-Weather-API-MalariaOutbreakWarning-
